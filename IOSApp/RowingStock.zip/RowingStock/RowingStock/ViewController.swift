//
//  ViewController.swift
//  RowingStock
//
//  Created by Allen Hosler on 8/11/18.
//  Copyright © 2018 Allen Hosler. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var stockName: UITextField!
    @IBOutlet weak var quantity: UITextField!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var composeMsg: UIBarButtonItem!
    
    var ref:DatabaseReference?
    var databaseHandle:DatabaseHandle?
    
    var postData = [Int]()
    var postKeyData = [String]()
    
    var priceData = [Double]()
    var priceKeyData = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.delegate = self
        tableView.dataSource = self
        
        //Set the Firebase Reference:
        ref = Database.database().reference()
        
        // Get Total vals
        ref?.child("user1").child("total").observe(.value, with: { (snapshot) in
            let newLabel = snapshot.value as! Double
            let str1 = "\(String(describing: newLabel))"
            self.totalLabel.text = (str1)
            self.tableView.reloadData()
        })
        
        // GENERAL PRICING
        
        databaseHandle = ref?.child("prices").observe(.childAdded, with: { (snapshot) in
            
            // code to execute when child is added under posts
            // take the value from the snapshot and add it to msg array
            let price = snapshot.value as? Double
            let priceKey = snapshot.key
            
            if let actualPrice = price {
                self.priceData.append(actualPrice)
                self.priceKeyData.append(priceKey)
                
                self.tableView.reloadData()
            }
            
        })
        // Remove any empty stock
        databaseHandle = ref?.child("prices").observe(.childRemoved, with: { (snapshot) in
            
            // code to execute when child is added under posts
            // take the value from the snapshot and add it to msg array
            let priceKey = snapshot.key
            
            let indexOfPrice = self.priceKeyData.index(of: priceKey)
            self.priceData.remove(at: indexOfPrice!)
            self.priceKeyData.remove(at: indexOfPrice!)
            
            self.tableView.reloadData()
            
        })
        
        // Update changes to stocks held
        databaseHandle = ref?.child("prices").observe(.childChanged, with: { (snapshot) in
            
            // code to execute when stock is changed under investment
            // take the value from the snapshot and add it to array
            let price = snapshot.value as? Double
            let priceKey = snapshot.key
            
            let indexOfPrice = self.priceKeyData.index(of: priceKey)
            self.priceData.remove(at: indexOfPrice!)
            self.priceKeyData.remove(at: indexOfPrice!)
            
            if let actualPrice = price {
                self.priceData.append(actualPrice)
                self.priceKeyData.append(priceKey)
            }
            
            self.tableView.reloadData()
            
        })
        
        // YOUR PERSONAL INVESTMENTS
        
        // Retrieve posts listen for changes
        databaseHandle = ref?.child("user1").child("investments").observe(.childAdded, with: { (snapshot) in
            
            // code to execute when child is added under posts
            // take the value from the snapshot and add it to msg array
            let post = snapshot.value as? Int
            let postKey = snapshot.key
            
            if let actualPost = post {
                self.postData.append(actualPost)
                self.postKeyData.append(postKey)
                
                self.tableView.reloadData()
            }
            
        })
        
        // Remove any empty stock
        databaseHandle = ref?.child("user1").child("investments").observe(.childRemoved, with: { (snapshot) in
            
            // code to execute when child is added under posts
            // take the value from the snapshot and add it to msg array
            let postKey = snapshot.key
            
            let indexOfPost = self.postKeyData.index(of: postKey)
            self.postData.remove(at: indexOfPost!)
            self.postKeyData.remove(at: indexOfPost!)
            
            self.tableView.reloadData()
            
        })
        
        // Update changes to stocks held
        databaseHandle = ref?.child("user1").child("investments").observe(.childChanged, with: { (snapshot) in
            
            // code to execute when stock is changed under investment
            // take the value from the snapshot and add it to array
            let post = snapshot.value as? Int
            let postKey = snapshot.key
            
            let indexOfPost = self.postKeyData.index(of: postKey)
            self.postData.remove(at: indexOfPost!)
            self.postKeyData.remove(at: indexOfPost!)
            
            if let actualPost = post {
                self.postData.append(actualPost)
                self.postKeyData.append(postKey)
            }
            
            self.tableView.reloadData()
            
        })
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell")
        cell?.textLabel?.text =  String(postData[indexPath.row]) + " pts of " + postKeyData[indexPath.row] + " at: " + String(priceData[indexPath.row]) + "units/pt"
        
        return cell!
    }
}

